function ObjVal = Sphere(Chrom,switc);
   
     Dim=size(Chrom,2);
   
      ObjVal = sum( Chrom.^2, 2 );
  
   end   
  

% End of function

